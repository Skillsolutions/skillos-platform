"use client";

import React, { useState, useEffect } from 'react';
import PlatformLayout from '@/components/platform/PlatformLayout';
import { UdemyConnector } from '../../../lib/udemy/connector';
import { SkillsGapAnalysis } from './SkillsGapAnalysis';
import { AnalyticsDashboard } from './AnalyticsDashboard';
import { BookOpen, Award, BarChart3, Search, Filter } from 'lucide-react';

// Define course type to fix TypeScript error
interface Course {
  id: string;
  title: string;
  headline: string;
  image_480x270: string;
  rating: number;
  num_reviews: number;
  content_info: string;
  instructors: { name: string }[];
  source: string;
}

// SkillOS Course Catalogue with Udemy Business API integration
export default function CourseCatalogueWithUdemy() {
  const [activeTab, setActiveTab] = useState('courses');
  const [loading, setLoading] = useState(true);
  const [courses, setCourses] = useState<Course[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    category: '',
    skillLevel: '',
    duration: '',
    source: 'all' // 'all', 'udemy', 'internal'
  });
  const [error, setError] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  // Initialize the Udemy connector
  const udemyConnector = new UdemyConnector({
    // Config will be loaded from environment variables in production
    mockMode: process.env.NODE_ENV !== 'production'
  });

  // Load courses on component mount and when filters change
  useEffect(() => {
    async function loadCourses() {
      try {
        setLoading(true);
        setError(null);
        
        let allCourses: Course[] = [];
        
        // Load Udemy courses if source is 'all' or 'udemy'
        if (filters.source === 'all' || filters.source === 'udemy') {
          try {
            // Initialize the connector if needed
            if (!udemyConnector.auth.token) {
              await udemyConnector.initialize();
            }
            
            // Search for courses with current filters
            const searchParams = {
              query: searchQuery,
              categoryIds: filters.category ? [filters.category] : [],
              // Map SkillOS skill levels to Udemy filter parameters
              skillLevel: filters.skillLevel
            };
            
            const udemyResults = await udemyConnector.searchCourses(searchParams);
            
            // Add source property to identify Udemy courses
            const udemyCourses = (udemyResults.items || []).map(course => ({
              ...course,
              source: 'udemy'
            }));
            
            allCourses = [...allCourses, ...udemyCourses];
          } catch (err) {
            console.error('Error loading Udemy courses:', err);
            // Continue with internal courses even if Udemy fails
          }
        }
        
        // Load internal courses if source is 'all' or 'internal'
        if (filters.source === 'all' || filters.source === 'internal') {
          // Mock internal courses for demonstration
          const internalCourses: Course[] = [
            {
              id: 'internal-1',
              title: 'SkillOS Onboarding',
              headline: 'Get started with the SkillOS platform',
              image_480x270: '/images/courses/onboarding.jpg',
              rating: 4.9,
              num_reviews: 120,
              content_info: '2 hours',
              instructors: [{ name: 'SkillOS Team' }],
              source: 'internal'
            },
            {
              id: 'internal-2',
              title: 'Leadership Fundamentals',
              headline: 'Essential skills for new managers',
              image_480x270: '/images/courses/leadership.jpg',
              rating: 4.8,
              num_reviews: 85,
              content_info: '4 hours',
              instructors: [{ name: 'Management Team' }],
              source: 'internal'
            }
          ];
          
          // Filter internal courses based on search query
          const filteredInternalCourses = searchQuery 
            ? internalCourses.filter(course => 
                course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                course.headline.toLowerCase().includes(searchQuery.toLowerCase())
              )
            : internalCourses;
            
          allCourses = [...allCourses, ...filteredInternalCourses];
        }
        
        setCourses(allCourses);
      } catch (err) {
        console.error('Error loading courses:', err);
        setError('Failed to load courses. Please try again later.');
      } finally {
        setLoading(false);
      }
    }
    
    loadCourses();
  }, [searchQuery, filters]);

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };
  
  // Handle filter changes
  const handleFilterChange = (filterName: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [filterName]: value
    }));
  };
  
  // Handle course launch
  const handleCourseLaunch = async (course: Course) => {
    try {
      if (course.source === 'udemy') {
        // In a real implementation, we would get the actual user ID
        const userId = 'current_user_id';
        const ssoUrl = await udemyConnector.generateCourseSSO(course.id, userId);
        
        // Open the course in a new tab
        window.open(ssoUrl, '_blank');
      } else {
        // Launch internal course
        window.open(`/platform/courses/${course.id}`, '_blank');
      }
    } catch (err) {
      console.error('Error launching course:', err);
      setError('Failed to launch course. Please try again.');
    }
  };

  return (
    <PlatformLayout title="Course Catalogue">
      <div className="course-catalogue">
        {/* Tabs */}
        <div className="flex flex-wrap border-b mb-6">
          <button
            className={`flex items-center py-2 px-4 ${activeTab === 'courses' ? 'border-b-2 border-blue-500 font-medium text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
            onClick={() => setActiveTab('courses')}
          >
            <BookOpen className="mr-2 h-4 w-4" />
            Courses
          </button>
          <button
            className={`flex items-center py-2 px-4 ${activeTab === 'skills-gap' ? 'border-b-2 border-blue-500 font-medium text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
            onClick={() => setActiveTab('skills-gap')}
          >
            <Award className="mr-2 h-4 w-4" />
            Skills Gap Analysis
          </button>
          <button
            className={`flex items-center py-2 px-4 ${activeTab === 'analytics' ? 'border-b-2 border-blue-500 font-medium text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
            onClick={() => setActiveTab('analytics')}
          >
            <BarChart3 className="mr-2 h-4 w-4" />
            Learning Analytics
          </button>
        </div>
      
      {/* Courses Tab */}
      {activeTab === 'courses' && (
        <>
          {/* Search and filters */}
          <div className="mb-6">
            <div className="flex gap-4 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="text"
                  placeholder="Search courses..."
                  value={searchQuery}
                  onChange={handleSearchChange}
                  className="flex-1 w-full p-2 pl-10 border rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
              <button 
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow-sm transition-colors"
                onClick={() => setSearchQuery(searchQuery)}
              >
                Search
              </button>
              <button
                className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg shadow-sm flex items-center transition-colors"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="mr-2" size={18} />
                Filters
              </button>
            </div>
            
            {showFilters && (
              <div className="bg-gray-50 p-4 rounded-lg shadow-sm mb-4 border border-gray-200 animate-fadeIn">
                <h3 className="font-medium mb-3 text-gray-700">Filter Courses</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Source</label>
                    <select 
                      value={filters.source}
                      onChange={(e) => handleFilterChange('source', e.target.value)}
                      className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    >
                      <option value="all">All Sources</option>
                      <option value="udemy">Udemy Business</option>
                      <option value="internal">Internal Courses</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select 
                      value={filters.category}
                      onChange={(e) => handleFilterChange('category', e.target.value)}
                      className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    >
                      <option value="">All Categories</option>
                      <option value="development">Development</option>
                      <option value="business">Business</option>
                      <option value="it-and-software">IT & Software</option>
                      <option value="data-science">Data Science</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Skill Level</label>
                    <select 
                      value={filters.skillLevel}
                      onChange={(e) => handleFilterChange('skillLevel', e.target.value)}
                      className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    >
                      <option value="">All Levels</option>
                      <option value="beginner">Beginner</option>
                      <option value="intermediate">Intermediate</option>
                      <option value="expert">Advanced</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Duration</label>
                    <select 
                      value={filters.duration}
                      onChange={(e) => handleFilterChange('duration', e.target.value)}
                      className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    >
                      <option value="">Any Duration</option>
                      <option value="short">0-3 Hours</option>
                      <option value="medium">3-6 Hours</option>
                      <option value="long">6+ Hours</option>
                    </select>
                  </div>
                </div>
              </div>
            )}
          
          {/* Error message */}
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}
          
          {/* Loading state */}
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            {/* Course grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.length > 0 ? (
                courses.map(course => (
                  <div key={`${course.source}-${course.id}`} className="border rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white">
                    <div className="relative">
                      <img 
                        src={course.image_480x270 || '/images/course-placeholder.jpg'} 
                        alt={course.title}
                        className="w-full h-48 object-cover"
                        onError={(e) => {
                          e.currentTarget.src = '/images/course-placeholder.jpg';
                        }}
                      />
                      <div className={`absolute top-0 right-0 ${course.source === 'udemy' ? 'bg-blue-600' : 'bg-green-600'} text-white text-xs px-2 py-1 m-2 rounded-md font-medium`}>
                        {course.source === 'udemy' ? 'Udemy Business' : 'Internal'}
                      </div>
                    </div>
                    
                    <div className="p-5">
                      <h3 className="font-bold text-lg mb-2 line-clamp-2 h-14">{course.title}</h3>
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2 h-10">{course.headline}</p>
                      
                      <div className="flex items-center mb-2">
                        <div className="flex text-yellow-500 mr-1">
                          {'★'.repeat(Math.round(course.rating))}
                          {'☆'.repeat(5 - Math.round(course.rating))}
                        </div>
                        <span className="font-medium ml-1">{course.rating.toFixed(1)}</span>
                        <span className="text-gray-500 text-sm ml-1">({course.num_reviews} reviews)</span>
                      </div>
                      
                      <div className="flex items-center text-sm text-gray-500 mb-4">
                        <span>{course.content_info || 'Self-paced'}</span>
                        {course.instructors && course.instructors.length > 0 && (
                          <>
                            <span className="mx-2">•</span>
                            <span className="truncate">{course.instructors[0]?.name}</span>
                          </>
                        )}
                      </div>
                      
                      <button
                        onClick={() => handleCourseLaunch(course)}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-colors duration-200 flex items-center justify-center"
                      >
                        <BookOpen className="mr-2 h-4 w-4" />
                        Launch Course
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-3 text-center py-12 bg-gray-50 rounded-lg">
                  <div className="flex flex-col items-center justify-center p-6">
                    <Search className="h-12 w-12 text-gray-400 mb-4" />
                    <p className="text-gray-500 text-lg mb-2">No courses found</p>
                    <p className="text-gray-400">Try adjusting your search or filters</p>
                  </div>
                </div>
              )}
            </div>         )}
        </>
      )}
      
      {/* Skills Gap Analysis Tab */}
      {activeTab === 'skills-gap' && (
        <SkillsGapAnalysis udemyConnector={udemyConnector} />
      )}
      
      {/* Analytics Tab */}
      {activeTab === 'analytics' && (
        <AnalyticsDashboard udemyConnector={udemyConnector} />
      )}
    </div>
    </PlatformLayout>
  );
}
