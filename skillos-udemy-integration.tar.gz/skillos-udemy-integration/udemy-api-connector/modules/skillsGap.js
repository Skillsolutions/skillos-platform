// Skills Gap Analysis Module for Udemy Business API
// Handles skills assessment, gap identification, and course recommendations

const { logger } = require('../utils/logger');

class SkillsGapModule {
  constructor(auth, courseDiscovery, config) {
    this.auth = auth;
    this.courseDiscovery = courseDiscovery;
    this.config = config;
    this.accountId = config.accountId;
  }

  /**
   * Analyze skills gap and recommend courses
   * @param {Array} userSkills - List of user's current skills with proficiency levels
   * @param {Array} targetSkills - List of target skills with required proficiency levels
   * @returns {Promise<Object>} - Skills gap analysis and course recommendations
   */
  async analyzeSkillsGap(userSkills, targetSkills) {
    try {
      logger.info('Analyzing skills gap');
      
      // Identify skills gaps
      const skillsGap = this.identifySkillsGap(userSkills, targetSkills);
      
      // Get course recommendations for skills gaps
      const recommendations = await this.getRecommendationsForSkillsGap(skillsGap);
      
      return {
        skillsGap,
        recommendations
      };
    } catch (error) {
      logger.error('Failed to analyze skills gap', error);
      throw new Error(`Skills gap analysis failed: ${error.message}`);
    }
  }

  /**
   * Identify skills gap between user skills and target skills
   * @param {Array} userSkills - List of user's current skills with proficiency levels
   * @param {Array} targetSkills - List of target skills with required proficiency levels
   * @returns {Array} - List of skill gaps with missing skills and proficiency differences
   */
  identifySkillsGap(userSkills, targetSkills) {
    logger.info('Identifying skills gap');
    
    const skillsGap = [];
    
    // Convert user skills to a map for easy lookup
    const userSkillsMap = new Map();
    userSkills.forEach(skill => {
      userSkillsMap.set(skill.name.toLowerCase(), skill.proficiency);
    });
    
    // Check each target skill against user skills
    targetSkills.forEach(targetSkill => {
      const skillName = targetSkill.name.toLowerCase();
      const requiredProficiency = targetSkill.proficiency;
      
      // If user doesn't have the skill or has lower proficiency
      if (!userSkillsMap.has(skillName)) {
        skillsGap.push({
          skill: targetSkill.name,
          requiredProficiency,
          currentProficiency: 0,
          gap: requiredProficiency,
          status: 'missing'
        });
      } else {
        const currentProficiency = userSkillsMap.get(skillName);
        if (currentProficiency < requiredProficiency) {
          skillsGap.push({
            skill: targetSkill.name,
            requiredProficiency,
            currentProficiency,
            gap: requiredProficiency - currentProficiency,
            status: 'insufficient'
          });
        }
      }
    });
    
    // Sort by gap size (descending)
    skillsGap.sort((a, b) => b.gap - a.gap);
    
    logger.info(`Identified ${skillsGap.length} skill gaps`);
    return skillsGap;
  }

  /**
   * Get course recommendations for skills gap
   * @param {Array} skillsGap - List of skill gaps
   * @returns {Promise<Object>} - Course recommendations by skill
   */
  async getRecommendationsForSkillsGap(skillsGap) {
    try {
      logger.info('Getting course recommendations for skills gap');
      
      const recommendations = {};
      
      // Get recommendations for each skill gap
      for (const gap of skillsGap) {
        try {
          const skillName = gap.skill;
          logger.info(`Finding courses for skill: ${skillName}`);
          
          // Search for courses related to the skill
          const searchResults = await this.courseDiscovery.search({
            search: skillName,
            page_size: 5,
            ordering: '-rating'
          });
          
          if (searchResults.results && searchResults.results.length > 0) {
            recommendations[skillName] = searchResults.results.map(course => ({
              id: course.id,
              title: course.title,
              url: course.url,
              rating: course.rating,
              image: course.image_480x270,
              headline: course.headline,
              instructors: course.visible_instructors ? course.visible_instructors.map(i => i.display_name).join(', ') : ''
            }));
          } else {
            recommendations[skillName] = [];
          }
        } catch (skillError) {
          logger.error(`Error getting recommendations for skill ${gap.skill}`, skillError);
          recommendations[gap.skill] = { error: skillError.message };
        }
      }
      
      return recommendations;
    } catch (error) {
      logger.error('Failed to get course recommendations', error);
      throw new Error(`Course recommendations failed: ${error.message}`);
    }
  }

  /**
   * Create personalized learning path based on skills gap
   * @param {Array} userSkills - List of user's current skills with proficiency levels
   * @param {Array} targetSkills - List of target skills with required proficiency levels
   * @param {string} pathName - Name for the learning path
   * @returns {Promise<Object>} - Personalized learning path
   */
  async createPersonalizedLearningPath(userSkills, targetSkills, pathName) {
    try {
      logger.info(`Creating personalized learning path: ${pathName}`);
      
      // Analyze skills gap
      const { skillsGap, recommendations } = await this.analyzeSkillsGap(userSkills, targetSkills);
      
      // Create learning path structure
      const learningPath = {
        name: pathName,
        description: `Personalized learning path to bridge skills gap in ${skillsGap.map(g => g.skill).join(', ')}`,
        sections: [],
        courses: []
      };
      
      // Add sections for each skill gap
      for (const gap of skillsGap) {
        const skillName = gap.skill;
        const skillCourses = recommendations[skillName] || [];
        
        if (skillCourses.length > 0) {
          // Add section for this skill
          learningPath.sections.push({
            name: `Develop ${skillName}`,
            description: `Courses to develop ${skillName} from level ${gap.currentProficiency} to ${gap.requiredProficiency}`,
            courses: skillCourses.map(course => course.id)
          });
          
          // Add courses to the overall course list
          learningPath.courses.push(...skillCourses);
        }
      }
      
      logger.info(`Created personalized learning path with ${learningPath.sections.length} sections and ${learningPath.courses.length} courses`);
      return learningPath;
    } catch (error) {
      logger.error('Failed to create personalized learning path', error);
      throw new Error(`Personalized learning path creation failed: ${error.message}`);
    }
  }

  /**
   * Get skill assessment for a user
   * @param {string} userId - User ID
   * @returns {Promise<Object>} - User skill assessment
   */
  async getUserSkillAssessment(userId) {
    try {
      logger.info(`Getting skill assessment for user: ${userId}`);
      
      // This would typically call an endpoint to get user skill assessment
      // Since we don't have access to this in the sandbox, we'll return a mock response
      
      logger.info('Returning mock skill assessment data');
      return {
        userId,
        assessmentDate: new Date().toISOString(),
        skills: [
          { name: 'JavaScript', proficiency: 3 },
          { name: 'Python', proficiency: 2 },
          { name: 'Data Analysis', proficiency: 1 },
          { name: 'Project Management', proficiency: 4 }
        ]
      };
    } catch (error) {
      logger.error(`Failed to get skill assessment for user ${userId}`, error);
      throw new Error(`Skill assessment retrieval failed: ${error.message}`);
    }
  }

  /**
   * Get role skill requirements
   * @param {string} roleId - Role ID
   * @returns {Promise<Object>} - Role skill requirements
   */
  async getRoleSkillRequirements(roleId) {
    try {
      logger.info(`Getting skill requirements for role: ${roleId}`);
      
      // This would typically call an endpoint to get role skill requirements
      // Since we don't have access to this in the sandbox, we'll return mock data
      
      const roleSkills = {
        'developer': [
          { name: 'JavaScript', proficiency: 4 },
          { name: 'Python', proficiency: 3 },
          { name: 'Git', proficiency: 3 },
          { name: 'DevOps', proficiency: 2 }
        ],
        'data-scientist': [
          { name: 'Python', proficiency: 4 },
          { name: 'Data Analysis', proficiency: 4 },
          { name: 'Machine Learning', proficiency: 3 },
          { name: 'SQL', proficiency: 3 }
        ],
        'project-manager': [
          { name: 'Project Management', proficiency: 5 },
          { name: 'Leadership', proficiency: 4 },
          { name: 'Communication', proficiency: 4 },
          { name: 'Agile Methodologies', proficiency: 3 }
        ]
      };
      
      if (roleSkills[roleId]) {
        logger.info(`Found skill requirements for role: ${roleId}`);
        return {
          roleId,
          skills: roleSkills[roleId]
        };
      } else {
        logger.error(`Role ${roleId} not found`);
        throw new Error(`Role ${roleId} not found`);
      }
    } catch (error) {
      logger.error(`Failed to get skill requirements for role ${roleId}`, error);
      throw new Error(`Role skill requirements retrieval failed: ${error.message}`);
    }
  }

  /**
   * Generate career development plan
   * @param {string} userId - User ID
   * @param {string} targetRoleId - Target role ID
   * @returns {Promise<Object>} - Career development plan
   */
  async generateCareerDevelopmentPlan(userId, targetRoleId) {
    try {
      logger.info(`Generating career development plan for user ${userId} targeting role ${targetRoleId}`);
      
      // Get user's current skills
      const userAssessment = await this.getUserSkillAssessment(userId);
      
      // Get target role skill requirements
      const roleRequirements = await this.getRoleSkillRequirements(targetRoleId);
      
      // Analyze skills gap and get recommendations
      const { skillsGap, recommendations } = await this.analyzeSkillsGap(
        userAssessment.skills,
        roleRequirements.skills
      );
      
      // Create personalized learning path
      const learningPath = await this.createPersonalizedLearningPath(
        userAssessment.skills,
        roleRequirements.skills,
        `Career Path: ${targetRoleId}`
      );
      
      // Generate development plan
      const developmentPlan = {
        userId,
        targetRole: targetRoleId,
        currentSkills: userAssessment.skills,
        targetSkills: roleRequirements.skills,
        skillsGap,
        recommendations,
        learningPath,
        generatedDate: new Date().toISOString()
      };
      
      logger.info('Successfully generated career development plan');
      return developmentPlan;
    } catch (error) {
      logger.error('Failed to generate career development plan', error);
      throw new Error(`Career development plan generation failed: ${error.message}`);
    }
  }
}

module.exports = SkillsGapModule;
