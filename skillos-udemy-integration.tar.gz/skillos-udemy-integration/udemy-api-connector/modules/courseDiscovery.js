// Course Discovery Module for Udemy Business API
// Handles course search, listing, and details retrieval

const { logger } = require('../utils/logger');

class CourseDiscoveryModule {
  constructor(auth, config) {
    this.auth = auth;
    this.config = config;
    this.accountId = config.accountId;
  }

  /**
   * Search for courses with various filters
   * @param {Object} params - Search parameters
   * @returns {Promise<Object>} - Search results with pagination
   */
  async search(params = {}) {
    try {
      logger.info('Searching courses with params:', params);
      
      const endpoint = `organizations/${this.accountId}/courses/list/`;
      
      // Default parameters
      const defaultParams = {
        page: 1,
        page_size: 20,
        'fields[course]': 'title,headline,url,image_480x270,visible_instructors,content_info,num_reviews,rating,price,is_paid'
      };
      
      // Merge default parameters with provided parameters
      const queryParams = { ...defaultParams, ...params };
      
      const response = await this.auth.makeRequest('get', endpoint, null, queryParams);
      
      logger.info(`Found ${response.count} courses matching search criteria`);
      return response;
    } catch (error) {
      logger.error('Course search failed', error);
      throw new Error(`Course search failed: ${error.message}`);
    }
  }

  /**
   * Get course details by ID
   * @param {string} courseId - Udemy course ID
   * @param {Object} params - Additional parameters like fields selection
   * @returns {Promise<Object>} - Course details
   */
  async getDetails(courseId, params = {}) {
    try {
      logger.info(`Getting details for course ID: ${courseId}`);
      
      // Use the direct courses endpoint which works in the sandbox environment
      const endpoint = `courses/${courseId}/`;
      
      // Default parameters for course details
      const defaultParams = {
        'fields[course]': 'title,headline,description,url,image_480x270,visible_instructors,content_info,num_reviews,rating,price,is_paid,requirements_data,what_you_will_learn_data,intended_audience,num_subscribers'
      };
      
      // Merge default parameters with provided parameters
      const queryParams = { ...defaultParams, ...params };
      
      const response = await this.auth.makeRequest('get', endpoint, null, queryParams);
      
      logger.info(`Successfully retrieved details for course: ${response.title}`);
      return response;
    } catch (error) {
      logger.error(`Failed to get course details for ${courseId}`, error);
      throw new Error(`Course details retrieval failed: ${error.message}`);
    }
  }

  /**
   * Get course curriculum (sections and lectures)
   * @param {string} courseId - Udemy course ID
   * @returns {Promise<Object>} - Course curriculum
   */
  async getCurriculum(courseId) {
    try {
      logger.info(`Getting curriculum for course ID: ${courseId}`);
      
      const endpoint = `organizations/${this.accountId}/courses/${courseId}/curriculum/`;
      
      const response = await this.auth.makeRequest('get', endpoint);
      
      logger.info(`Successfully retrieved curriculum with ${response.results.length} sections`);
      return response;
    } catch (error) {
      logger.error(`Failed to get curriculum for course ${courseId}`, error);
      throw new Error(`Course curriculum retrieval failed: ${error.message}`);
    }
  }

  /**
   * Generate SSO URL for course launch
   * @param {string} courseId - Udemy course ID
   * @param {string} userId - User ID for SSO
   * @param {string} returnUrl - Optional return URL after course completion
   * @returns {Promise<string>} - SSO URL for course launch
   */
  async generateSSO(courseId, userId, returnUrl = null) {
    try {
      logger.info(`Generating SSO URL for course ${courseId} and user ${userId}`);
      
      // Construct course URL
      const courseUrl = `https://sksolutions-sandbox.udemy.com/course/${courseId}/`;
      
      // Generate SSO URL with the auth module
      const ssoUrl = await this.auth.generateSSOUrl(userId, returnUrl || courseUrl);
      
      logger.info('Successfully generated SSO URL');
      return ssoUrl;
    } catch (error) {
      logger.error(`Failed to generate SSO for course ${courseId}`, error);
      throw new Error(`SSO generation failed: ${error.message}`);
    }
  }

  /**
   * Get course categories
   * @returns {Promise<Array>} - List of categories
   */
  async getCategories() {
    try {
      logger.info('Getting course categories');
      
      const endpoint = `organizations/${this.accountId}/categories/`;
      
      const response = await this.auth.makeRequest('get', endpoint);
      
      logger.info(`Successfully retrieved ${response.results.length} categories`);
      return response.results;
    } catch (error) {
      logger.error('Failed to get categories', error);
      throw new Error(`Categories retrieval failed: ${error.message}`);
    }
  }

  /**
   * Search courses by skill
   * @param {Array} skills - List of skills to search for
   * @param {Object} params - Additional search parameters
   * @returns {Promise<Object>} - Search results
   */
  async searchBySkills(skills = [], params = {}) {
    try {
      logger.info(`Searching courses by skills: ${skills.join(', ')}`);
      
      // Convert skills array to search query
      const skillsQuery = skills.join(' OR ');
      
      // Add skills to search parameters
      const searchParams = {
        ...params,
        search: skillsQuery
      };
      
      return await this.search(searchParams);
    } catch (error) {
      logger.error('Failed to search courses by skills', error);
      throw new Error(`Skills-based search failed: ${error.message}`);
    }
  }

  /**
   * Get popular courses
   * @param {number} limit - Number of courses to return
   * @returns {Promise<Array>} - List of popular courses
   */
  async getPopularCourses(limit = 10) {
    try {
      logger.info(`Getting top ${limit} popular courses`);
      
      const params = {
        page: 1,
        page_size: limit,
        ordering: '-num_subscribers',
        'fields[course]': 'title,headline,url,image_480x270,visible_instructors,num_subscribers,rating'
      };
      
      const response = await this.search(params);
      
      return response.results;
    } catch (error) {
      logger.error('Failed to get popular courses', error);
      throw new Error(`Popular courses retrieval failed: ${error.message}`);
    }
  }

  /**
   * Get newest courses
   * @param {number} limit - Number of courses to return
   * @returns {Promise<Array>} - List of newest courses
   */
  async getNewestCourses(limit = 10) {
    try {
      logger.info(`Getting ${limit} newest courses`);
      
      const params = {
        page: 1,
        page_size: limit,
        ordering: '-created',
        'fields[course]': 'title,headline,url,image_480x270,visible_instructors,created,rating'
      };
      
      const response = await this.search(params);
      
      return response.results;
    } catch (error) {
      logger.error('Failed to get newest courses', error);
      throw new Error(`Newest courses retrieval failed: ${error.message}`);
    }
  }
}

module.exports = CourseDiscoveryModule;
