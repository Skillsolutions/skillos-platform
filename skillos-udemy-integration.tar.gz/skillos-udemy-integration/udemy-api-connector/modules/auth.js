// Authentication Module for Udemy Business API
// Handles Basic Auth for API access and SSO functionality

const axios = require('axios');
const { logger } = require('../utils/logger');

class AuthModule {
  constructor(config) {
    this.config = config;
    this.baseUrl = config.baseUrl || 'https://business-api.udemy.com';
    this.clientId = config.clientId;
    this.clientSecret = config.clientSecret;
    this.accountId = config.accountId;
    this.retryCount = 0;
    this.maxRetries = 3;
  }

  /**
   * Get Basic Auth headers for Udemy Business API
   * @returns {Object} - Headers object with Basic Auth
   */
  getBasicAuthHeaders() {
    // Create Basic Auth header with client ID and secret
    const auth = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString('base64');
    
    return {
      'Authorization': `Basic ${auth}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
  }

  /**
   * Make an authenticated API request
   * @param {string} method - HTTP method
   * @param {string} endpoint - API endpoint
   * @param {Object} data - Request data (for POST, PUT)
   * @param {Object} params - Query parameters
   * @returns {Promise<Object>} - API response
   */
  async makeRequest(method, endpoint, data = null, params = {}) {
    try {
      const headers = this.getBasicAuthHeaders();
      const url = endpoint.startsWith('http') ? endpoint : `${this.baseUrl}/${endpoint}`;
      
      logger.debug(`Making ${method} request to ${url}`);
      
      const response = await axios({
        method,
        url,
        headers,
        data,
        params
      });
      
      // Reset retry count on successful request
      this.retryCount = 0;
      
      return response.data;
    } catch (error) {
      logger.error(`API request failed: ${error.message}`, error.response?.data || error);
      
      // Handle rate limiting (429)
      if (error.response && error.response.status === 429) {
        const retryAfter = parseInt(error.response.headers['retry-after'] || '5', 10);
        logger.info(`Rate limited. Retrying after ${retryAfter} seconds`);
        
        return new Promise((resolve, reject) => {
          setTimeout(async () => {
            try {
              const result = await this.makeRequest(method, endpoint, data, params);
              resolve(result);
            } catch (retryError) {
              reject(retryError);
            }
          }, retryAfter * 1000);
        });
      }
      
      // Implement retry logic with exponential backoff for other errors
      if (this.retryCount < this.maxRetries) {
        this.retryCount++;
        const backoffTime = Math.pow(2, this.retryCount) * 1000; // Exponential backoff
        logger.info(`Retrying request in ${backoffTime}ms (attempt ${this.retryCount} of ${this.maxRetries})`);
        
        return new Promise((resolve, reject) => {
          setTimeout(async () => {
            try {
              const result = await this.makeRequest(method, endpoint, data, params);
              resolve(result);
            } catch (retryError) {
              reject(retryError);
            }
          }, backoffTime);
        });
      }
      
      throw new Error(`API request failed after ${this.maxRetries} attempts: ${error.message}`);
    }
  }

  /**
   * Generate SSO URL for a user
   * @param {string} userId - User ID for SSO
   * @param {string} returnUrl - URL to return to after authentication
   * @returns {Promise<string>} - SSO URL
   */
  async generateSSOUrl(userId, returnUrl) {
    try {
      const endpoint = `organizations/${this.accountId}/sso/generate`;
      const data = {
        user_id: userId,
        return_url: returnUrl
      };
      
      const response = await this.makeRequest('post', endpoint, data);
      return response.sso_url;
    } catch (error) {
      logger.error('Failed to generate SSO URL', error);
      throw new Error(`SSO URL generation failed: ${error.message}`);
    }
  }
}

module.exports = AuthModule;
