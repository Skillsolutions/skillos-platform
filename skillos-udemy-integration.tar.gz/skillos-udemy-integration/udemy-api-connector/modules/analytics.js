// Reporting and Analytics Module for Udemy Business API
// Handles data retrieval for course engagement, user activity, and learning metrics

const { logger } = require('../utils/logger');

class AnalyticsModule {
  constructor(auth, config) {
    this.auth = auth;
    this.config = config;
    this.accountId = config.accountId;
  }

  /**
   * Get course activity metrics
   * @param {Object} params - Query parameters for filtering
   * @returns {Promise<Object>} - Course activity data
   */
  async getCourseActivity(params = {}) {
    try {
      logger.info('Retrieving course activity metrics');
      
      const endpoint = `organizations/${this.accountId}/analytics/course-activity/`;
      
      // Default parameters
      const defaultParams = {
        page: 1,
        page_size: 50,
        'fields[course_activity]': 'course,num_enrolled,num_lectures_completed,num_lectures_started,num_students_completed,num_students_started,completion_ratio,hours_taught'
      };
      
      // Merge default parameters with provided parameters
      const queryParams = { ...defaultParams, ...params };
      
      const response = await this.auth.makeRequest('get', endpoint, null, queryParams);
      
      logger.info(`Retrieved activity data for ${response.results.length} courses`);
      return response;
    } catch (error) {
      logger.error('Failed to retrieve course activity metrics', error);
      throw new Error(`Course activity retrieval failed: ${error.message}`);
    }
  }

  /**
   * Get user learning activity
   * @param {Object} params - Query parameters for filtering
   * @returns {Promise<Object>} - User learning activity data
   */
  async getUserActivity(params = {}) {
    try {
      logger.info('Retrieving user learning activity');
      
      const endpoint = `organizations/${this.accountId}/analytics/user-activity/`;
      
      // Default parameters
      const defaultParams = {
        page: 1,
        page_size: 50,
        'fields[user_activity]': 'user,num_courses_enrolled,num_courses_completed,num_lectures_started,num_lectures_completed,num_quizzes_completed,learning_time'
      };
      
      // Merge default parameters with provided parameters
      const queryParams = { ...defaultParams, ...params };
      
      const response = await this.auth.makeRequest('get', endpoint, null, queryParams);
      
      logger.info(`Retrieved activity data for ${response.results.length} users`);
      return response;
    } catch (error) {
      logger.error('Failed to retrieve user activity metrics', error);
      throw new Error(`User activity retrieval failed: ${error.message}`);
    }
  }

  /**
   * Get course engagement metrics
   * @param {string} courseId - Udemy course ID
   * @returns {Promise<Object>} - Course engagement data
   */
  async getCourseEngagement(courseId) {
    try {
      logger.info(`Retrieving engagement metrics for course ID: ${courseId}`);
      
      const endpoint = `organizations/${this.accountId}/analytics/courses/${courseId}/engagement/`;
      
      const response = await this.auth.makeRequest('get', endpoint);
      
      logger.info(`Successfully retrieved engagement metrics for course ID: ${courseId}`);
      return response;
    } catch (error) {
      logger.error(`Failed to retrieve engagement metrics for course ${courseId}`, error);
      throw new Error(`Course engagement retrieval failed: ${error.message}`);
    }
  }

  /**
   * Get learning insights summary
   * @returns {Promise<Object>} - Learning insights summary data
   */
  async getLearningInsights() {
    try {
      logger.info('Retrieving learning insights summary');
      
      const endpoint = `organizations/${this.accountId}/analytics/insights/`;
      
      const response = await this.auth.makeRequest('get', endpoint);
      
      logger.info('Successfully retrieved learning insights summary');
      return response;
    } catch (error) {
      logger.error('Failed to retrieve learning insights', error);
      throw new Error(`Learning insights retrieval failed: ${error.message}`);
    }
  }

  /**
   * Get top courses by engagement
   * @param {number} limit - Number of courses to return
   * @returns {Promise<Array>} - List of top courses
   */
  async getTopCourses(limit = 10) {
    try {
      logger.info(`Retrieving top ${limit} courses by engagement`);
      
      const params = {
        page: 1,
        page_size: limit,
        ordering: '-completion_ratio'
      };
      
      const response = await this.getCourseActivity(params);
      
      return response.results;
    } catch (error) {
      logger.error('Failed to retrieve top courses', error);
      throw new Error(`Top courses retrieval failed: ${error.message}`);
    }
  }

  /**
   * Get course completion rates
   * @param {Array} courseIds - List of course IDs to get completion rates for
   * @returns {Promise<Object>} - Completion rates by course
   */
  async getCompletionRates(courseIds = []) {
    try {
      logger.info(`Retrieving completion rates for ${courseIds.length} courses`);
      
      const results = {};
      
      // If no course IDs provided, get overall completion rates
      if (courseIds.length === 0) {
        const response = await this.getCourseActivity();
        
        response.results.forEach(course => {
          results[course.course.id] = {
            title: course.course.title,
            completion_ratio: course.completion_ratio,
            num_enrolled: course.num_enrolled,
            num_completed: course.num_students_completed
          };
        });
      } else {
        // Get completion rates for specific courses
        for (const courseId of courseIds) {
          try {
            const params = {
              'filter[course]': courseId
            };
            
            const response = await this.getCourseActivity(params);
            
            if (response.results.length > 0) {
              const courseData = response.results[0];
              results[courseId] = {
                title: courseData.course.title,
                completion_ratio: courseData.completion_ratio,
                num_enrolled: courseData.num_enrolled,
                num_completed: courseData.num_students_completed
              };
            }
          } catch (courseError) {
            logger.error(`Error getting completion rate for course ${courseId}`, courseError);
            results[courseId] = { error: courseError.message };
          }
        }
      }
      
      return results;
    } catch (error) {
      logger.error('Failed to retrieve completion rates', error);
      throw new Error(`Completion rates retrieval failed: ${error.message}`);
    }
  }

  /**
   * Get learning time metrics
   * @param {Object} params - Query parameters for filtering
   * @returns {Promise<Object>} - Learning time metrics
   */
  async getLearningTime(params = {}) {
    try {
      logger.info('Retrieving learning time metrics');
      
      const endpoint = `organizations/${this.accountId}/analytics/learning-time/`;
      
      // Default parameters
      const defaultParams = {
        page: 1,
        page_size: 50
      };
      
      // Merge default parameters with provided parameters
      const queryParams = { ...defaultParams, ...params };
      
      const response = await this.auth.makeRequest('get', endpoint, null, queryParams);
      
      logger.info('Successfully retrieved learning time metrics');
      return response;
    } catch (error) {
      logger.error('Failed to retrieve learning time metrics', error);
      throw new Error(`Learning time metrics retrieval failed: ${error.message}`);
    }
  }

  /**
   * Get skills development metrics
   * @returns {Promise<Object>} - Skills development data
   */
  async getSkillsDevelopment() {
    try {
      logger.info('Retrieving skills development metrics');
      
      const endpoint = `organizations/${this.accountId}/analytics/skills/`;
      
      const response = await this.auth.makeRequest('get', endpoint);
      
      logger.info('Successfully retrieved skills development metrics');
      return response;
    } catch (error) {
      logger.error('Failed to retrieve skills development metrics', error);
      throw new Error(`Skills development metrics retrieval failed: ${error.message}`);
    }
  }
}

module.exports = AnalyticsModule;
