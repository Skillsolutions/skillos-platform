// Udemy Business API Configuration
module.exports = {
  clientId: "nE5uF4wm0S62hFNrBg28bjgsIifCb124n4rd845E",
  clientSecret: "t2FHdGtY9iIkyoVSjFLabOebz9KQGbX4sSJrgCU8ABVPGiXedbyd2dAh02cbcqeuRq1HOK46nGrCEjylKwJCWGbVGf2sIvZJSsDA1cxo33tAWslCzEQvsJ6ao68UTNf7",
  baseUrl: "https://sksolutions-sandbox.udemy.com/api-2.0",
  graphqlUrl: "https://sksolutions-sandbox.udemy.com/graphql",
  xapiEndpoint: "https://sksolutions-sandbox.udemy.com/api-2.0/xapi",
  accountId: "388939",
  logLevel: "info",
  cacheEnabled: true,
  cacheExpiry: 3600
};
