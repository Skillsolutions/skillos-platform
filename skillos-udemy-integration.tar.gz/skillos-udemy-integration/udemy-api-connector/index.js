// Main entry point for Udemy Business API Connector
// Integrates all modules for comprehensive API access

const AuthModule = require('./modules/auth');
const CourseDiscoveryModule = require('./modules/courseDiscovery');
const AnalyticsModule = require('./modules/analytics');
const LearningPathsModule = require('./modules/learningPaths');
const SkillsGapModule = require('./modules/skillsGap');
const config = require('./config');
const { logger } = require('./utils/logger');

/**
 * UdemyConnector - Main class for Udemy Business API integration
 * Provides access to all API features through a unified interface
 */
class UdemyConnector {
  /**
   * Create a new UdemyConnector instance
   * @param {Object} customConfig - Optional custom configuration to override defaults
   */
  constructor(customConfig = {}) {
    // Merge default config with custom config
    this.config = { ...config, ...customConfig };
    
    // Initialize authentication module
    this.auth = new AuthModule(this.config);
    
    // Initialize feature modules
    this.courseDiscovery = new CourseDiscoveryModule(this.auth, this.config);
    this.analytics = new AnalyticsModule(this.auth, this.config);
    this.learningPaths = new LearningPathsModule(this.auth, this.config);
    this.skillsGap = new SkillsGapModule(this.auth, this.courseDiscovery, this.config);
    
    logger.info('UdemyConnector initialized');
  }
  
  /**
   * Get connector status and capabilities
   * @returns {Object} - Status information about the connector
   */
  getStatus() {
    return {
      initialized: true,
      config: {
        baseUrl: this.config.baseUrl,
        accountId: this.config.accountId,
        features: {
          courseDiscovery: true,
          analytics: true,
          learningPaths: true,
          skillsGap: true
        }
      },
      version: '1.0.0'
    };
  }
  
  /**
   * Search for courses with various filters
   * @param {Object} params - Search parameters
   * @returns {Promise<Object>} - Search results with pagination
   */
  async searchCourses(params = {}) {
    try {
      return await this.courseDiscovery.search(params);
    } catch (error) {
      logger.error('Error in searchCourses', error);
      throw error;
    }
  }
  
  /**
   * Get course details by ID
   * @param {string} courseId - Udemy course ID
   * @param {Object} params - Additional parameters
   * @returns {Promise<Object>} - Course details
   */
  async getCourseDetails(courseId, params = {}) {
    try {
      return await this.courseDiscovery.getDetails(courseId, params);
    } catch (error) {
      logger.error(`Error in getCourseDetails for course ${courseId}`, error);
      throw error;
    }
  }
  
  /**
   * Get popular courses
   * @param {number} limit - Number of courses to return
   * @returns {Promise<Array>} - List of popular courses
   */
  async getPopularCourses(limit = 10) {
    try {
      return await this.courseDiscovery.getPopularCourses(limit);
    } catch (error) {
      logger.error('Error in getPopularCourses', error);
      throw error;
    }
  }
  
  /**
   * Get newest courses
   * @param {number} limit - Number of courses to return
   * @returns {Promise<Array>} - List of newest courses
   */
  async getNewestCourses(limit = 10) {
    try {
      return await this.courseDiscovery.getNewestCourses(limit);
    } catch (error) {
      logger.error('Error in getNewestCourses', error);
      throw error;
    }
  }
  
  /**
   * Get user activity metrics
   * @param {Object} params - Query parameters
   * @returns {Promise<Object>} - User activity data
   */
  async getUserActivity(params = {}) {
    try {
      return await this.analytics.getUserActivity(params);
    } catch (error) {
      logger.error('Error in getUserActivity', error);
      throw error;
    }
  }
  
  /**
   * List learning paths
   * @param {Object} params - Query parameters
   * @returns {Promise<Object>} - List of learning paths
   */
  async listLearningPaths(params = {}) {
    try {
      return await this.learningPaths.listLearningPaths(params);
    } catch (error) {
      logger.error('Error in listLearningPaths', error);
      throw error;
    }
  }
  
  /**
   * Search learning paths
   * @param {string} query - Search query
   * @param {Object} params - Additional parameters
   * @returns {Promise<Object>} - Search results
   */
  async searchLearningPaths(query, params = {}) {
    try {
      return await this.learningPaths.searchLearningPaths(query, params);
    } catch (error) {
      logger.error('Error in searchLearningPaths', error);
      throw error;
    }
  }
  
  /**
   * Analyze skills gap and recommend courses
   * @param {Array} userSkills - User's current skills
   * @param {Array} targetSkills - Target skills
   * @returns {Promise<Object>} - Skills gap analysis and recommendations
   */
  async analyzeSkillsGap(userSkills, targetSkills) {
    try {
      return await this.skillsGap.analyzeSkillsGap(userSkills, targetSkills);
    } catch (error) {
      logger.error('Error in analyzeSkillsGap', error);
      throw error;
    }
  }
  
  /**
   * Generate career development plan
   * @param {string} userId - User ID
   * @param {string} targetRoleId - Target role ID
   * @returns {Promise<Object>} - Career development plan
   */
  async generateCareerDevelopmentPlan(userId, targetRoleId) {
    try {
      return await this.skillsGap.generateCareerDevelopmentPlan(userId, targetRoleId);
    } catch (error) {
      logger.error('Error in generateCareerDevelopmentPlan', error);
      throw error;
    }
  }
  
  /**
   * Generate SSO URL for course launch
   * @param {string} courseId - Course ID
   * @param {string} userId - User ID
   * @param {string} returnUrl - Return URL
   * @returns {Promise<string>} - SSO URL
   */
  async generateCourseSSO(courseId, userId, returnUrl = null) {
    try {
      return await this.courseDiscovery.generateSSO(courseId, userId, returnUrl);
    } catch (error) {
      logger.error(`Error in generateCourseSSO for course ${courseId}`, error);
      throw error;
    }
  }
}

module.exports = UdemyConnector;
