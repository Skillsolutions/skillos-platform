"use client";

import React, { useState } from 'react';
import PlatformLayout from "@/components/platform/PlatformLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { 
  Bell, Send, Award, Calendar, Download, CheckCircle, AlertCircle, 
  User, Users, Clock, FileText, MessageSquare, Flag, Target, 
  Zap, Settings, ChevronRight, Plus, Edit, Trash2, Copy, 
  ArrowRight, Star, UserPlus, MessageCircle, Bookmark, 
  Lightbulb, Sparkles, UserCheck, Rocket, Trophy, Mail, X,
  Megaphone, Globe, UserCircle, Building, Layers, Filter
} from "lucide-react";
import { format } from 'date-fns';
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

// Define types for audience selection
interface AudienceMember {
  id: string;
  name: string;
  department?: string;
  role?: string;
}

interface Team {
  id: string;
  name: string;
  department: string;
  members: number;
}

interface Department {
  id: string;
  name: string;
  members: number;
}

interface CampaignAudience {
  type: string;
  specific: (AudienceMember | Team | Department)[];
}

interface CampaignData {
  title: string;
  description: string;
  type: string;
  template: string;
  startDate: Date;
  endDate: Date;
  audience: CampaignAudience;
  content: any[];
  rewards: {
    points: number;
    badges: boolean;
    certificates: boolean;
  };
}

interface Template {
  id: string;
  title: string;
  description: string;
  type: string;
  content: string;
}

interface Campaign {
  id: string;
  title: string;
  description: string;
  type: string;
  startDate: string;
  endDate: string;
  status: string;
  audience: {
    type: string;
    count: number;
  };
  progress: number;
  courses: number;
}

interface CampaignTemplate {
  id: string;
  title: string;
  description: string;
  type: string;
  duration: number;
  courses: string[];
  image: string;
}

const EngagementPlannerPage = () => {
  // State for active tab
  const [activeTab, setActiveTab] = useState("smart-nudges");
  
  // State for dialogs
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);
  const [showChallengeDialog, setShowChallengeDialog] = useState(false);
  const [showRecognitionDialog, setShowRecognitionDialog] = useState(false);
  const [showCampaignDialog, setShowCampaignDialog] = useState(false);
  const [showAudienceDialog, setShowAudienceDialog] = useState(false);
  const [currentTemplate, setCurrentTemplate] = useState<Template | null>(null);
  
  // State for campaign creation
  const [campaignStep, setCampaignStep] = useState(1);
  const [campaignData, setCampaignData] = useState<CampaignData>({
    title: '',
    description: '',
    type: '',
    template: '',
    startDate: new Date(),
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
    audience: {
      type: 'all',
      specific: []
    },
    content: [],
    rewards: {
      points: 100,
      badges: true,
      certificates: true
    }
  });
  
  // State for settings
  const [settings, setSettings] = useState({
    nudgeFrequency: "weekly",
    challengeOptIn: true,
    autoRecognition: true,
    slackIntegration: true,
    emailIntegration: true,
    teamsIntegration: false
  });
  
  // Mock data for smart nudges
  const smartNudges = [
    {
      id: "nudge1",
      type: "inactivity",
      message: "3 team members inactive for 2+ weeks",
      action: "Send Nudge",
      priority: "high",
      users: ["Alex Johnson", "Maria Garcia", "David Kim"]
    },
    {
      id: "nudge2",
      type: "completion",
      message: "Sara completed Conflict Management",
      action: "Endorse Application",
      priority: "medium",
      users: ["Sara Wilson"]
    },
    {
      id: "nudge3",
      type: "dropout",
      message: "Omar dropped off a course",
      action: "Follow Up",
      priority: "medium",
      users: ["Omar Hassan"]
    },
    {
      id: "nudge4",
      type: "milestone",
      message: "Team reached 80% completion on Technical Skills",
      action: "Recognize Achievement",
      priority: "low",
      users: ["Frontend Team"]
    },
    {
      id: "nudge5",
      type: "recommendation",
      message: "5 team members might benefit from Leadership course",
      action: "Review Suggestion",
      priority: "medium",
      users: ["New Managers Group"]
    }
  ];
  
  // Mock data for quick actions
  const quickActions = [
    {
      id: "action1",
      title: "Set Learning Goals",
      description: "Establish clear objectives for your team",
      icon: <Target className="h-5 w-5 text-blue-500" />,
      action: "Assign Goal",
      color: "blue"
    },
    {
      id: "action2",
      title: "Schedule 1:1 Review",
      description: "Plan individual learning progress discussions",
      icon: <Calendar className="h-5 w-5 text-purple-500" />,
      action: "Download Summary PDF",
      color: "purple"
    },
    {
      id: "action3",
      title: "Recommend Path",
      description: "AI-based learning path suggestions",
      icon: <Lightbulb className="h-5 w-5 text-amber-500" />,
      action: "Get Suggestions",
      color: "amber"
    },
    {
      id: "action4",
      title: "Monthly Recognition Setup",
      description: "Automatically highlight top performers",
      icon: <Trophy className="h-5 w-5 text-green-500" />,
      action: "Auto Highlight Top Learner",
      color: "green"
    }
  ];
  
  // Mock data for recognition tools
  const recognitionTools = [
    {
      id: "recognition1",
      title: "Endorse Skill Application",
      description: "Acknowledge when skills are applied in real work",
      icon: <CheckCircle className="h-5 w-5 text-green-500" />,
      action: "Tag skill + context"
    },
    {
      id: "recognition2",
      title: "Send Shout-Out",
      description: "Publicly recognize achievements in team channels",
      icon: <MessageCircle className="h-5 w-5 text-blue-500" />,
      action: "Slack/MS Teams message"
    },
    {
      id: "recognition3",
      title: "Issue Badge",
      description: "Award digital badges for accomplishments",
      icon: <Award className="h-5 w-5 text-amber-500" />,
      action: "Track-based or peer-nominated"
    },
    {
      id: "recognition4",
      title: "View Recognition History",
      description: "See all past recognition activities",
      icon: <Clock className="h-5 w-5 text-purple-500" />,
      action: "Timeline by person"
    }
  ];
  
  // Mock data for challenges
  const challenges = [
    {
      id: "challenge1",
      title: "Complete a Data course this month",
      type: "Team Challenge",
      participants: 12,
      progress: 65,
      deadline: "May 30, 2025"
    },
    {
      id: "challenge2",
      title: "Apply a new skill in your daily work",
      type: "Micro-Mission",
      participants: 8,
      progress: 50,
      deadline: "May 25, 2025"
    },
    {
      id: "challenge3",
      title: "Share one learning insight weekly",
      type: "Team Challenge",
      participants: 15,
      progress: 80,
      deadline: "Ongoing"
    },
    {
      id: "challenge4",
      title: "Mentor a colleague for 15 minutes",
      type: "Micro-Mission",
      participants: 5,
      progress: 40,
      deadline: "May 28, 2025"
    }
  ];
  
  // Mock data for templates
  const templates: Template[] = [
    {
      id: "template1",
      title: "Learning Kickoff Email",
      description: "Introduce a new learning initiative to your team",
      type: "email",
      content: `Subject: Exciting New Learning Opportunity: [Course/Program Name]

Dear [Team Member],

I'm excited to announce a new learning opportunity that I believe will be valuable for your professional development: [Course/Program Name].

This [duration] program will help you develop skills in [key skills], which aligns with both your career goals and our team's objectives for this quarter.

Key benefits include:
• [Benefit 1]
• [Benefit 2]
• [Benefit 3]

The program starts on [Start Date]. Please complete it by [End Date].

I'd love to discuss how you can apply these new skills to your current projects during our next 1:1.

Best regards,
[Your Name]`
    },
    {
      id: "template2",
      title: "1:1 Discussion Guide",
      description: "Structure for learning-focused 1:1 meetings",
      type: "document",
      content: `# Learning-Focused 1:1 Discussion Guide

## Recent Learning Review (10 min)
- What courses/modules have you completed since our last meeting?
- What were your key takeaways?
- How have you applied or plan to apply what you've learned?

## Challenges & Support (10 min)
- What obstacles are you facing in your learning journey?
- What resources or support would help you overcome these challenges?
- Are there specific skills you'd like more guidance on?

## Goals & Next Steps (10 min)
- Progress on current learning goals
- Adjustments needed to learning plan
- Specific commitments before next meeting

## Action Items
- [Manager] Action items:
  - 
  - 
- [Team Member] Action items:
  - 
  - 

Next meeting date: __________`
    },
    {
      id: "template3",
      title: "Recognition Message",
      description: "Template for acknowledging learning achievements",
      type: "message",
      content: `@[Team Member Name] I wanted to recognize your outstanding commitment to professional development! 

Your recent completion of [Course/Program] and how you've already applied [Specific Skill] to [Specific Project/Task] has made a real impact on [Specific Outcome].

This is exactly the kind of growth mindset and skill application we value on our team. Thank you for your dedication to continuous improvement!

#TeamLearning #SkillsInAction`
    },
    {
      id: "template4",
      title: "Team Learning Plan",
      description: "Quarterly learning strategy for your team",
      type: "document",
      content: `# Quarterly Team Learning Plan

## Team: [Team Name]
## Quarter: [Q1/Q2/Q3/Q4] [Year]

### Focus Areas
1. [Skill Area 1]
2. [Skill Area 2]
3. [Skill Area 3]

### Learning Objectives
By the end of this quarter, our team will:
- [Objective 1]
- [Objective 2]
- [Objective 3]

### Recommended Learning Paths
| Team Member | Primary Focus | Recommended Courses | Deadline |
|-------------|---------------|---------------------|----------|
| [Name]      | [Focus]       | [Courses]           | [Date]   |
| [Name]      | [Focus]       | [Courses]           | [Date]   |

### Application Opportunities
- [Project/Task where skills can be applied]
- [Project/Task where skills can be applied]

### Success Metrics
- [Metric 1]
- [Metric 2]
- [Metric 3]

### Check-in Schedule
- Mid-quarter review: [Date]
- End-quarter celebration: [Date]`
    }
  ];
  
  // Mock data for campaigns
  const campaigns: Campaign[] = [
    {
      id: "campaign1",
      title: "New Year Learning Resolutions",
      description: "Start the year with new skills and knowledge",
      type: "seasonal",
      startDate: "Jan 1, 2025",
      endDate: "Jan 31, 2025",
      status: "scheduled",
      audience: {
        type: "all",
        count: 250
      },
      progress: 0,
      courses: 5
    },
    {
      id: "campaign2",
      title: "Women in Leadership",
      description: "Special learning path for Women's Day",
      type: "special",
      startDate: "Mar 1, 2025",
      endDate: "Mar 31, 2025",
      status: "draft",
      audience: {
        type: "custom",
        count: 85
      },
      progress: 0,
      courses: 3
    },
    {
      id: "campaign3",
      title: "Ramadan Reflection & Growth",
      description: "Personal development during Ramadan",
      type: "seasonal",
      startDate: "Mar 10, 2025",
      endDate: "Apr 9, 2025",
      status: "draft",
      audience: {
        type: "custom",
        count: 120
      },
      progress: 0,
      courses: 4
    },
    {
      id: "campaign4",
      title: "Q3 Learning Sprint",
      description: "Accelerated skill development for Q3 objectives",
      type: "quarterly",
      startDate: "Jul 1, 2025",
      endDate: "Sep 30, 2025",
      status: "draft",
      audience: {
        type: "department",
        count: 45
      },
      progress: 0,
      courses: 8
    },
    {
      id: "campaign5",
      title: "Technical Skills Bootcamp",
      description: "Intensive technical upskilling program",
      type: "skills",
      startDate: "Jun 1, 2025",
      endDate: "Jul 15, 2025",
      status: "active",
      audience: {
        type: "team",
        count: 18
      },
      progress: 35,
      courses: 6
    }
  ];
  
  // Mock data for campaign templates
  const campaignTemplates: CampaignTemplate[] = [
    {
      id: "campaignTemplate1",
      title: "New Year Learning Resolutions",
      description: "Start the year with new skills and knowledge",
      type: "seasonal",
      duration: 30,
      courses: ["Goal Setting Mastery", "Productivity Fundamentals", "Growth Mindset"],
      image: "/images/campaigns/new-year.jpg"
    },
    {
      id: "campaignTemplate2",
      title: "Women in Leadership",
      description: "Special learning path for Women's Day",
      type: "special",
      duration: 30,
      courses: ["Women in Leadership", "Effective Communication", "Strategic Thinking"],
      image: "/images/campaigns/womens-day.jpg"
    },
    {
      id: "campaignTemplate3",
      title: "Ramadan Reflection & Growth",
      description: "Personal development during Ramadan",
      type: "seasonal",
      duration: 30,
      courses: ["Mindfulness Basics", "Work-Life Balance", "Personal Reflection"],
      image: "/images/campaigns/ramadan.jpg"
    },
    {
      id: "campaignTemplate4",
      title: "Q3 Learning Sprint",
      description: "Accelerated skill development for Q3 objectives",
      type: "quarterly",
      duration: 90,
      courses: ["Strategic Planning", "Project Management", "Data Analysis", "Presentation Skills"],
      image: "/images/campaigns/q3.jpg"
    }
  ];
  
  // Mock data for audience selection
  const audienceOptions = {
    individuals: [
      { id: "user1", name: "Alex Johnson", department: "Engineering", role: "Developer" },
      { id: "user2", name: "Maria Garcia", department: "Marketing", role: "Content Strategist" },
      { id: "user3", name: "David Kim", department: "Sales", role: "Account Executive" },
      { id: "user4", name: "Sara Wilson", department: "Engineering", role: "Product Manager" },
      { id: "user5", name: "Omar Hassan", department: "Finance", role: "Financial Analyst" }
    ] as AudienceMember[],
    teams: [
      { id: "team1", name: "Frontend Team", department: "Engineering", members: 8 },
      { id: "team2", name: "Content Team", department: "Marketing", members: 6 },
      { id: "team3", name: "Enterprise Sales", department: "Sales", members: 12 },
      { id: "team4", name: "Mobile Development", department: "Engineering", members: 5 },
      { id: "team5", name: "Financial Planning", department: "Finance", members: 7 }
    ] as Team[],
    departments: [
      { id: "dept1", name: "Engineering", members: 45 },
      { id: "dept2", name: "Marketing", members: 22 },
      { id: "dept3", name: "Sales", members: 30 },
      { id: "dept4", name: "Finance", members: 15 },
      { id: "dept5", name: "Human Resources", members: 8 }
    ] as Department[]
  };
  
  // Handle template selection
  const handleTemplateSelect = (template: Template) => {
    setCurrentTemplate(template);
    setShowTemplateDialog(true);
  };
  
  // Handle settings change
  const handleSettingChange = (setting: string, value: any) => {
    setSettings({
      ...settings,
      [setting]: value
    });
  };
  
  // Handle campaign creation steps
  const handleCampaignStepChange = (step: number) => {
    setCampaignStep(step);
  };
  
  // Handle campaign data change
  const handleCampaignDataChange = (field: string, value: any) => {
    setCampaignData({
      ...campaignData,
      [field]: value
    });
  };
  
  // Handle campaign template selection
  const handleCampaignTemplateSelect = (template: CampaignTemplate) => {
    setCampaignData({
      ...campaignData,
      title: template.title,
      description: template.description,
      type: template.type,
      template: template.id,
      endDate: new Date(campaignData.startDate.getTime() + template.duration * 24 * 60 * 60 * 1000),
    });
    
    handleCampaignStepChange(2);
  };
  
  // Handle audience selection
  const handleAudienceSelect = (type: string, specific: (AudienceMember | Team | Department)[] = []) => {
    setCampaignData({
      ...campaignData,
      audience: {
        type,
        specific
      }
    });
    
    setShowAudienceDialog(false);
  };
  
  // Handle campaign creation
  const handleCreateCampaign = () => {
    // In a real implementation, this would save the campaign to the database
    console.log("Creating campaign:", campaignData);
    
    // Close the dialog and reset the form
    setShowCampaignDialog(false);
    setCampaignStep(1);
    setCampaignData({
      title: '',
      description: '',
      type: '',
      template: '',
      startDate: new Date(),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      audience: {
        type: 'all',
        specific: []
      },
      content: [],
      rewards: {
        points: 100,
        badges: true,
        certificates: true
      }
    });
  };
  
  return (
    <PlatformLayout title="Engagement Planner">
      <div className="container mx-auto py-6">
        <h1 className="text-3xl font-bold mb-2">Engagement Planner</h1>
        <p className="text-gray-500 mb-6">Tools to boost learning engagement and application</p>
        
        {/* Main tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="smart-nudges" className="flex items-center gap-2">
              <Bell className="h-4 w-4" />
              <span>Smart Nudges</span>
            </TabsTrigger>
            <TabsTrigger value="quick-actions" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              <span>Quick Actions</span>
            </TabsTrigger>
            <TabsTrigger value="recognition" className="flex items-center gap-2">
              <Award className="h-4 w-4" />
              <span>Recognition</span>
            </TabsTrigger>
            <TabsTrigger value="challenges" className="flex items-center gap-2">
              <Flag className="h-4 w-4" />
              <span>Challenges</span>
            </TabsTrigger>
            <TabsTrigger value="campaigns" className="flex items-center gap-2">
              <Megaphone className="h-4 w-4" />
              <span>Campaigns</span>
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span>Templates</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              <span>Settings</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Smart Nudges Tab */}
          <TabsContent value="smart-nudges">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold">Smart Nudges</h2>
              <div className="flex gap-2">
                <Select defaultValue="all">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="inactivity">Inactivity</SelectItem>
                    <SelectItem value="completion">Completion</SelectItem>
                    <SelectItem value="dropout">Dropout</SelectItem>
                    <SelectItem value="milestone">Milestone</SelectItem>
                    <SelectItem value="recommendation">Recommendation</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon">
                  <span className="sr-only">Refresh</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
                    <path d="M21 3v5h-5" />
                    <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
                    <path d="M3 21v-5h5" />
                  </svg>
                </Button>
              </div>
            </div>
            
            <p className="text-gray-500 mb-6">Dynamic suggestions based on team activity and learning patterns</p>
            
            <div className="space-y-4">
              {smartNudges.map((nudge) => (
                <Card key={nudge.id} className="overflow-hidden">
                  <div className={`border-l-4 ${
                    nudge.priority === 'high' ? 'border-red-500' :
                    nudge.priority === 'medium' ? 'border-amber-500' : 'border-blue-500'
                  }`}>
                    <CardContent className="p-0">
                      <div className="flex items-start p-4 gap-4">
                        <div className={`rounded-full p-2 ${
                          nudge.type === 'inactivity' ? 'bg-red-100 text-red-500' :
                          nudge.type === 'completion' ? 'bg-green-100 text-green-500' :
                          nudge.type === 'dropout' ? 'bg-amber-100 text-amber-500' :
                          nudge.type === 'milestone' ? 'bg-blue-100 text-blue-500' :
                          'bg-purple-100 text-purple-500'
                        }`}>
                          {nudge.type === 'inactivity' ? <AlertCircle className="h-5 w-5" /> :
                           nudge.type === 'completion' ? <CheckCircle className="h-5 w-5" /> :
                           nudge.type === 'dropout' ? <User className="h-5 w-5" /> :
                           nudge.type === 'milestone' ? <Flag className="h-5 w-5" /> :
                           <Lightbulb className="h-5 w-5" />}
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">{nudge.message}</h3>
                              <p className="text-sm text-gray-500">{nudge.users.join(', ')}</p>
                            </div>
                            <Badge variant={
                              nudge.priority === 'high' ? 'destructive' :
                              nudge.priority === 'medium' ? 'default' : 'secondary'
                            }>
                              {nudge.priority.charAt(0).toUpperCase() + nudge.priority.slice(1)}
                            </Badge>
                          </div>
                        </div>
                        <Button size="sm">
                          {nudge.action}
                        </Button>
                      </div>
                    </CardContent>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          {/* Quick Actions Tab */}
          <TabsContent value="quick-actions">
            <h2 className="text-2xl font-semibold mb-6">Quick Actions</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {quickActions.map((action) => (
                <Card key={action.id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div className={`rounded-full p-2 bg-${action.color}-100`}>
                        {action.icon}
                      </div>
                      <Button variant="ghost" size="sm">
                        {action.action}
                      </Button>
                    </div>
                    <CardTitle className="mt-4">{action.title}</CardTitle>
                    <CardDescription>{action.description}</CardDescription>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          {/* Recognition Tab */}
          <TabsContent value="recognition">
            <h2 className="text-2xl font-semibold mb-6">Recognition Tools</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {recognitionTools.map((tool) => (
                <Card key={tool.id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div className="rounded-full p-2 bg-gray-100">
                        {tool.icon}
                      </div>
                    </div>
                    <CardTitle className="mt-4">{tool.title}</CardTitle>
                    <CardDescription>{tool.description}</CardDescription>
                  </CardHeader>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      {tool.action}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          {/* Challenges Tab */}
          <TabsContent value="challenges">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold">Challenges & Micro-Missions</h2>
              <Button onClick={() => setShowChallengeDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Challenge
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {challenges.map((challenge) => (
                <Card key={challenge.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <Badge variant={challenge.type === "Team Challenge" ? "default" : "secondary"}>
                        {challenge.type}
                      </Badge>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <CardTitle className="mt-2">{challenge.title}</CardTitle>
                    <div className="flex items-center text-sm text-gray-500">
                      <Users className="h-4 w-4 mr-1" />
                      <span>{challenge.participants} participants</span>
                      <span className="mx-2">•</span>
                      <Clock className="h-4 w-4 mr-1" />
                      <span>Due {challenge.deadline}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{challenge.progress}%</span>
                      </div>
                      <Progress value={challenge.progress} />
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                    <Button size="sm">
                      Send Reminder
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          {/* Campaigns Tab */}
          <TabsContent value="campaigns">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold">Learning Campaigns</h2>
              <Button onClick={() => setShowCampaignDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Campaign
              </Button>
            </div>
            
            <div className="flex gap-4 mb-6">
              <Select defaultValue="all">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
              
              <Select defaultValue="all">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="seasonal">Seasonal</SelectItem>
                  <SelectItem value="special">Special Event</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="skills">Skills-based</SelectItem>
                </SelectContent>
              </Select>
              
              <Input 
                placeholder="Search campaigns..." 
                className="flex-1"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {campaigns.map((campaign) => (
                <Card key={campaign.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <Badge variant={
                        campaign.status === "active" ? "default" :
                        campaign.status === "scheduled" ? "secondary" :
                        campaign.status === "draft" ? "outline" : "destructive"
                      }>
                        {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                      </Badge>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <CardTitle className="mt-2">{campaign.title}</CardTitle>
                    <CardDescription>{campaign.description}</CardDescription>
                    <div className="flex items-center text-sm text-gray-500 mt-2">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>{campaign.startDate} - {campaign.endDate}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between text-sm">
                        <div className="flex items-center">
                          {campaign.audience.type === "all" ? (
                            <Globe className="h-4 w-4 mr-1" />
                          ) : campaign.audience.type === "team" ? (
                            <Users className="h-4 w-4 mr-1" />
                          ) : campaign.audience.type === "department" ? (
                            <Building className="h-4 w-4 mr-1" />
                          ) : (
                            <Filter className="h-4 w-4 mr-1" />
                          )}
                          <span>
                            {campaign.audience.type === "all" ? "All Employees" :
                             campaign.audience.type === "team" ? "Team" :
                             campaign.audience.type === "department" ? "Department" :
                             "Custom Group"}
                          </span>
                          <span className="ml-1 text-gray-400">({campaign.audience.count})</span>
                        </div>
                        <div className="flex items-center">
                          <Layers className="h-4 w-4 mr-1" />
                          <span>{campaign.courses} courses</span>
                        </div>
                      </div>
                      
                      {campaign.status === "active" && (
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Progress</span>
                            <span>{campaign.progress}%</span>
                          </div>
                          <Progress value={campaign.progress} />
                        </div>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                    {campaign.status === "active" && (
                      <Button size="sm">
                        Send Reminder
                      </Button>
                    )}
                    {campaign.status === "scheduled" && (
                      <Button size="sm">
                        Edit Schedule
                      </Button>
                    )}
                    {campaign.status === "draft" && (
                      <Button size="sm">
                        Launch Campaign
                      </Button>
                    )}
                    {campaign.status === "completed" && (
                      <Button size="sm">
                        View Results
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          {/* Templates Tab */}
          <TabsContent value="templates">
            <h2 className="text-2xl font-semibold mb-6">Communication Templates</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {templates.map((template) => (
                <Card key={template.id} className="cursor-pointer hover:border-blue-200" onClick={() => handleTemplateSelect(template)}>
                  <CardHeader>
                    <Badge variant="outline">{template.type}</Badge>
                    <CardTitle className="mt-2">{template.title}</CardTitle>
                    <CardDescription>{template.description}</CardDescription>
                  </CardHeader>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm">
                      Preview
                    </Button>
                    <Button size="sm">
                      Use Template
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          {/* Settings Tab */}
          <TabsContent value="settings">
            <h2 className="text-2xl font-semibold mb-6">Engagement Settings</h2>
            
            <Card>
              <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
                <CardDescription>Configure how and when engagement notifications are sent</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="nudge-frequency">Nudge Frequency</Label>
                    <p className="text-sm text-gray-500">How often to receive smart nudges</p>
                  </div>
                  <Select 
                    value={settings.nudgeFrequency}
                    onValueChange={(value) => handleSettingChange('nudgeFrequency', value)}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="manual">Manual only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Challenge Opt-in</Label>
                    <p className="text-sm text-gray-500">Allow team members to opt in/out of challenges</p>
                  </div>
                  <Switch 
                    checked={settings.challengeOptIn}
                    onCheckedChange={(checked) => handleSettingChange('challengeOptIn', checked)}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Automatic Recognition</Label>
                    <p className="text-sm text-gray-500">Suggest recognition for major achievements</p>
                  </div>
                  <Switch 
                    checked={settings.autoRecognition}
                    onCheckedChange={(checked) => handleSettingChange('autoRecognition', checked)}
                  />
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Integrations</h3>
                  
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="slack" 
                        checked={settings.slackIntegration}
                        onCheckedChange={(checked) => handleSettingChange('slackIntegration', checked)}
                      />
                      <Label htmlFor="slack">Slack</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="email" 
                        checked={settings.emailIntegration}
                        onCheckedChange={(checked) => handleSettingChange('emailIntegration', checked)}
                      />
                      <Label htmlFor="email">Email</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="teams" 
                        checked={settings.teamsIntegration}
                        onCheckedChange={(checked) => handleSettingChange('teamsIntegration', checked)}
                      />
                      <Label htmlFor="teams">Microsoft Teams</Label>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button>Save Settings</Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Template Dialog */}
      <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{currentTemplate?.title}</DialogTitle>
            <DialogDescription>{currentTemplate?.description}</DialogDescription>
          </DialogHeader>
          
          <div className="border rounded-md p-4 bg-gray-50 max-h-96 overflow-y-auto">
            <pre className="whitespace-pre-wrap font-mono text-sm">
              {currentTemplate?.content}
            </pre>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTemplateDialog(false)}>
              Cancel
            </Button>
            <Button>
              Use Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Challenge Dialog */}
      <Dialog open={showChallengeDialog} onOpenChange={setShowChallengeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Challenge</DialogTitle>
            <DialogDescription>Set up a learning challenge for your team</DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="challenge-type">Challenge Type</Label>
              <Select defaultValue="team">
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="team">Team Challenge</SelectItem>
                  <SelectItem value="micro">Micro-Mission</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="challenge-title">Title</Label>
              <Input id="challenge-title" placeholder="Enter challenge title" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="challenge-description">Description</Label>
              <Textarea id="challenge-description" placeholder="Describe the challenge" />
            </div>
            
            <div className="space-y-2">
              <Label>Deadline</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <Calendar className="mr-2 h-4 w-4" />
                    <span>Pick a date</span>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarComponent
                    mode="single"
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2">
              <Label>Participants</Label>
              <Select defaultValue="team">
                <SelectTrigger>
                  <SelectValue placeholder="Select participants" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="team">Entire Team</SelectItem>
                  <SelectItem value="select">Select Individuals</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowChallengeDialog(false)}>
              Cancel
            </Button>
            <Button>
              Create Challenge
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Campaign Dialog */}
      <Dialog open={showCampaignDialog} onOpenChange={setShowCampaignDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Create Learning Campaign</DialogTitle>
            <DialogDescription>
              {campaignStep === 1 && "Select a campaign template or create your own"}
              {campaignStep === 2 && "Choose your target audience"}
              {campaignStep === 3 && "Review and launch your campaign"}
            </DialogDescription>
          </DialogHeader>
          
          {/* Step 1: Campaign Template Selection */}
          {campaignStep === 1 && (
            <div className="space-y-6 py-4">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Campaign Details</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="campaign-title">Campaign Title</Label>
                    <Input 
                      id="campaign-title" 
                      placeholder="Enter campaign title"
                      value={campaignData.title}
                      onChange={(e) => handleCampaignDataChange('title', e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="campaign-type">Campaign Type</Label>
                    <Select 
                      value={campaignData.type}
                      onValueChange={(value) => handleCampaignDataChange('type', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="seasonal">Seasonal</SelectItem>
                        <SelectItem value="special">Special Event</SelectItem>
                        <SelectItem value="quarterly">Quarterly</SelectItem>
                        <SelectItem value="skills">Skills-based</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="campaign-description">Description</Label>
                  <Textarea 
                    id="campaign-description" 
                    placeholder="Describe the campaign"
                    value={campaignData.description}
                    onChange={(e) => handleCampaignDataChange('description', e.target.value)}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <Calendar className="mr-2 h-4 w-4" />
                          <span>{format(campaignData.startDate, 'PPP')}</span>
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <CalendarComponent
                          mode="single"
                          selected={campaignData.startDate}
                          onSelect={(date) => date && handleCampaignDataChange('startDate', date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>End Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <Calendar className="mr-2 h-4 w-4" />
                          <span>{format(campaignData.endDate, 'PPP')}</span>
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <CalendarComponent
                          mode="single"
                          selected={campaignData.endDate}
                          onSelect={(date) => date && handleCampaignDataChange('endDate', date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Pre-made Templates</h3>
                <p className="text-sm text-gray-500">Choose a template to get started quickly</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {campaignTemplates.map((template) => (
                    <Card 
                      key={template.id} 
                      className={`cursor-pointer hover:border-blue-200 ${
                        campaignData.template === template.id ? 'border-blue-500 ring-2 ring-blue-200' : ''
                      }`}
                      onClick={() => handleCampaignTemplateSelect(template)}
                    >
                      <CardHeader className="pb-2">
                        <Badge variant="outline">{template.type}</Badge>
                        <CardTitle className="mt-2">{template.title}</CardTitle>
                        <CardDescription>{template.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-sm text-gray-500">
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1" />
                            <span>{template.duration} days</span>
                          </div>
                          <div className="flex items-center mt-1">
                            <Layers className="h-4 w-4 mr-1" />
                            <span>{template.courses.length} courses</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {/* Step 2: Audience Selection */}
          {campaignStep === 2 && (
            <div className="space-y-6 py-4">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Target Audience</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <Card 
                    className={`cursor-pointer hover:border-blue-200 ${
                      campaignData.audience.type === 'all' ? 'border-blue-500 ring-2 ring-blue-200' : ''
                    }`}
                    onClick={() => handleAudienceSelect('all', [])}
                  >
                    <CardHeader className="text-center">
                      <div className="mx-auto bg-blue-100 rounded-full p-3 w-12 h-12 flex items-center justify-center">
                        <Globe className="h-6 w-6 text-blue-500" />
                      </div>
                      <CardTitle className="mt-2">All Employees</CardTitle>
                      <CardDescription>Target everyone in the organization</CardDescription>
                    </CardHeader>
                  </Card>
                  
                  <Card 
                    className={`cursor-pointer hover:border-blue-200 ${
                      campaignData.audience.type === 'department' ? 'border-blue-500 ring-2 ring-blue-200' : ''
                    }`}
                    onClick={() => setShowAudienceDialog(true)}
                  >
                    <CardHeader className="text-center">
                      <div className="mx-auto bg-purple-100 rounded-full p-3 w-12 h-12 flex items-center justify-center">
                        <Building className="h-6 w-6 text-purple-500" />
                      </div>
                      <CardTitle className="mt-2">Departments</CardTitle>
                      <CardDescription>Target specific departments</CardDescription>
                    </CardHeader>
                  </Card>
                  
                  <Card 
                    className={`cursor-pointer hover:border-blue-200 ${
                      campaignData.audience.type === 'team' ? 'border-blue-500 ring-2 ring-blue-200' : ''
                    }`}
                    onClick={() => setShowAudienceDialog(true)}
                  >
                    <CardHeader className="text-center">
                      <div className="mx-auto bg-green-100 rounded-full p-3 w-12 h-12 flex items-center justify-center">
                        <Users className="h-6 w-6 text-green-500" />
                      </div>
                      <CardTitle className="mt-2">Teams</CardTitle>
                      <CardDescription>Target specific teams</CardDescription>
                    </CardHeader>
                  </Card>
                  
                  <Card 
                    className={`cursor-pointer hover:border-blue-200 ${
                      campaignData.audience.type === 'individuals' ? 'border-blue-500 ring-2 ring-blue-200' : ''
                    }`}
                    onClick={() => setShowAudienceDialog(true)}
                  >
                    <CardHeader className="text-center">
                      <div className="mx-auto bg-amber-100 rounded-full p-3 w-12 h-12 flex items-center justify-center">
                        <UserCircle className="h-6 w-6 text-amber-500" />
                      </div>
                      <CardTitle className="mt-2">Individuals</CardTitle>
                      <CardDescription>Target specific employees</CardDescription>
                    </CardHeader>
                  </Card>
                </div>
                
                {campaignData.audience.specific.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-sm font-medium mb-2">Selected Audience:</h4>
                    <div className="flex flex-wrap gap-2">
                      {campaignData.audience.specific.map((item) => (
                        <Badge key={item.id} variant="secondary">
                          {item.name}
                          <button className="ml-1" onClick={(e) => {
                            e.stopPropagation();
                            handleAudienceSelect(
                              campaignData.audience.type,
                              campaignData.audience.specific.filter(i => i.id !== item.id)
                            );
                          }}>
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {/* Step 3: Review and Launch */}
          {campaignStep === 3 && (
            <div className="space-y-6 py-4">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Campaign Summary</h3>
                
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Campaign Title</h4>
                          <p>{campaignData.title}</p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Campaign Type</h4>
                          <p>{campaignData.type.charAt(0).toUpperCase() + campaignData.type.slice(1)}</p>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Description</h4>
                        <p>{campaignData.description}</p>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Start Date</h4>
                          <p>{format(campaignData.startDate, 'PPP')}</p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">End Date</h4>
                          <p>{format(campaignData.endDate, 'PPP')}</p>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Target Audience</h4>
                        <p>
                          {campaignData.audience.type === 'all' ? 'All Employees' :
                           campaignData.audience.type === 'department' ? 'Departments' :
                           campaignData.audience.type === 'team' ? 'Teams' : 'Individuals'}
                          {campaignData.audience.specific.length > 0 && (
                            <span className="text-gray-500"> ({campaignData.audience.specific.length} selected)</span>
                          )}
                        </p>
                        {campaignData.audience.specific.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {campaignData.audience.specific.map((item) => (
                              <Badge key={item.id} variant="outline" className="text-xs">
                                {item.name}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Campaign Settings</h4>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="send-notification" defaultChecked />
                      <Label htmlFor="send-notification">Send notification to participants</Label>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="auto-reminders" defaultChecked />
                      <Label htmlFor="auto-reminders">Enable automatic reminders</Label>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="track-progress" defaultChecked />
                      <Label htmlFor="track-progress">Track progress and completion</Label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            {campaignStep > 1 && (
              <Button 
                variant="outline" 
                onClick={() => handleCampaignStepChange(campaignStep - 1)}
              >
                Back
              </Button>
            )}
            
            {campaignStep < 3 ? (
              <Button onClick={() => handleCampaignStepChange(campaignStep + 1)}>
                Continue
              </Button>
            ) : (
              <Button onClick={handleCreateCampaign}>
                Launch Campaign
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Audience Selection Dialog */}
      <Dialog open={showAudienceDialog} onOpenChange={setShowAudienceDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Select Target Audience</DialogTitle>
            <DialogDescription>
              {campaignData.audience.type === 'department' ? 'Choose departments to target' :
               campaignData.audience.type === 'team' ? 'Choose teams to target' :
               'Choose individuals to target'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Input placeholder="Search..." className="mb-4" />
            
            <div className="max-h-96 overflow-y-auto space-y-2">
              {campaignData.audience.type === 'department' && audienceOptions.departments.map((dept) => (
                <div key={dept.id} className="flex items-center justify-between p-2 hover:bg-gray-100 rounded-md">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id={dept.id} 
                      checked={campaignData.audience.specific.some(item => item.id === dept.id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          handleAudienceSelect(
                            'department',
                            [...campaignData.audience.specific, dept]
                          );
                        } else {
                          handleAudienceSelect(
                            'department',
                            campaignData.audience.specific.filter(item => item.id !== dept.id)
                          );
                        }
                      }}
                    />
                    <Label htmlFor={dept.id} className="cursor-pointer">{dept.name}</Label>
                  </div>
                  <Badge variant="outline">{dept.members} members</Badge>
                </div>
              ))}
              
              {campaignData.audience.type === 'team' && audienceOptions.teams.map((team) => (
                <div key={team.id} className="flex items-center justify-between p-2 hover:bg-gray-100 rounded-md">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id={team.id} 
                      checked={campaignData.audience.specific.some(item => item.id === team.id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          handleAudienceSelect(
                            'team',
                            [...campaignData.audience.specific, team]
                          );
                        } else {
                          handleAudienceSelect(
                            'team',
                            campaignData.audience.specific.filter(item => item.id !== team.id)
                          );
                        }
                      }}
                    />
                    <Label htmlFor={team.id} className="cursor-pointer">{team.name}</Label>
                  </div>
                  <div className="text-sm text-gray-500">
                    <span className="mr-2">{team.department}</span>
                    <Badge variant="outline">{team.members} members</Badge>
                  </div>
                </div>
              ))}
              
              {campaignData.audience.type === 'individuals' && audienceOptions.individuals.map((user) => (
                <div key={user.id} className="flex items-center justify-between p-2 hover:bg-gray-100 rounded-md">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id={user.id} 
                      checked={campaignData.audience.specific.some(item => item.id === user.id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          handleAudienceSelect(
                            'individuals',
                            [...campaignData.audience.specific, user]
                          );
                        } else {
                          handleAudienceSelect(
                            'individuals',
                            campaignData.audience.specific.filter(item => item.id !== user.id)
                          );
                        }
                      }}
                    />
                    <Label htmlFor={user.id} className="cursor-pointer">{user.name}</Label>
                  </div>
                  <div className="text-sm text-gray-500">
                    <span>{user.department}</span>
                    <span className="mx-1">•</span>
                    <span>{user.role}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAudienceDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowAudienceDialog(false)}>
              Confirm Selection
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PlatformLayout>
  );
};

export default EngagementPlannerPage;
