// SkillOS Platform Integration for Udemy Business API Connector
// Provides integration between SkillOS platform and Udemy Business API

const UdemyConnector = require('./index');
const { logger } = require('./utils/logger');

/**
 * SkillOS integration for Udemy Business API
 * Connects SkillOS platform with Udemy Business courses, analytics, and learning paths
 */
class SkillOSUdemyIntegration {
  /**
   * Create a new SkillOSUdemyIntegration instance
   * @param {Object} config - Configuration object with Udemy API credentials
   */
  constructor(config = {}) {
    this.connector = new UdemyConnector(config);
    logger.info('SkillOS Udemy Integration initialized');
  }
  
  /**
   * Get course catalog for SkillOS platform
   * @param {Object} filters - Optional filters for the catalog
   * @param {number} page - Page number for pagination
   * @param {number} pageSize - Number of items per page
   * @returns {Promise<Object>} - Course catalog with pagination
   */
  async getCourseCatalog(filters = {}, page = 1, pageSize = 20) {
    try {
      logger.info('Getting course catalog for SkillOS platform');
      
      const searchParams = {
        ...filters,
        page,
        page_size: pageSize
      };
      
      const coursesResponse = await this.connector.searchCourses(searchParams);
      
      // Transform to SkillOS format
      return {
        total: coursesResponse.count,
        page,
        pageSize,
        hasMore: !!coursesResponse.next,
        courses: coursesResponse.results.map(course => ({
          id: course.id,
          title: course.title,
          description: course.headline || '',
          imageUrl: course.image_480x270,
          instructors: course.visible_instructors ? course.visible_instructors.map(i => i.display_name).join(', ') : '',
          rating: course.rating || 0,
          enrollmentCount: course.num_subscribers || 0,
          url: course.url,
          source: 'udemy'
        }))
      };
    } catch (error) {
      logger.error('Error getting course catalog for SkillOS', error);
      throw new Error(`Failed to get course catalog: ${error.message}`);
    }
  }
  
  /**
   * Get course details for SkillOS platform
   * @param {string} courseId - Udemy course ID
   * @returns {Promise<Object>} - Course details in SkillOS format
   */
  async getCourseDetails(courseId) {
    try {
      logger.info(`Getting course details for SkillOS platform: ${courseId}`);
      
      const courseDetails = await this.connector.getCourseDetails(courseId);
      
      // Transform to SkillOS format
      return {
        id: courseDetails.id,
        title: courseDetails.title,
        description: courseDetails.description || courseDetails.headline || '',
        imageUrl: courseDetails.image_480x270,
        instructors: courseDetails.visible_instructors ? courseDetails.visible_instructors.map(i => i.display_name).join(', ') : '',
        rating: courseDetails.rating || 0,
        enrollmentCount: courseDetails.num_subscribers || 0,
        url: courseDetails.url,
        requirements: courseDetails.requirements_data || [],
        whatYouWillLearn: courseDetails.what_you_will_learn_data || [],
        intendedAudience: courseDetails.intended_audience || '',
        source: 'udemy'
      };
    } catch (error) {
      logger.error(`Error getting course details for SkillOS: ${courseId}`, error);
      throw new Error(`Failed to get course details: ${error.message}`);
    }
  }
  
  /**
   * Get learning paths for SkillOS platform
   * @param {Object} filters - Optional filters for learning paths
   * @param {number} page - Page number for pagination
   * @param {number} pageSize - Number of items per page
   * @returns {Promise<Object>} - Learning paths with pagination
   */
  async getLearningPaths(filters = {}, page = 1, pageSize = 20) {
    try {
      logger.info('Getting learning paths for SkillOS platform');
      
      const params = {
        ...filters,
        page,
        page_size: pageSize
      };
      
      const pathsResponse = await this.connector.listLearningPaths(params);
      
      // Transform to SkillOS format
      return {
        total: pathsResponse.count,
        page,
        pageSize,
        hasMore: !!pathsResponse.next,
        learningPaths: pathsResponse.results.map(path => ({
          id: path.id,
          title: path.title,
          description: path.description || '',
          numberOfItems: path.number_of_content_items || 0,
          estimatedDuration: path.estimated_content_length || 0,
          categories: path.categories || [],
          source: 'udemy'
        }))
      };
    } catch (error) {
      logger.error('Error getting learning paths for SkillOS', error);
      
      // Return empty result with error info if sandbox restrictions prevent access
      if (error.message.includes('404') || error.message.includes('403')) {
        logger.warn('Learning paths access restricted in sandbox environment');
        return {
          total: 0,
          page,
          pageSize,
          hasMore: false,
          learningPaths: [],
          error: 'Learning paths access restricted in sandbox environment'
        };
      }
      
      throw new Error(`Failed to get learning paths: ${error.message}`);
    }
  }
  
  /**
   * Get user learning activity for SkillOS platform
   * @param {string} userId - User ID in SkillOS
   * @returns {Promise<Object>} - User learning activity in SkillOS format
   */
  async getUserLearningActivity(userId) {
    try {
      logger.info(`Getting user learning activity for SkillOS: ${userId}`);
      
      const userActivity = await this.connector.getUserActivity();
      
      // Find the user's activity or return empty data
      const userRecord = userActivity.results.find(u => 
        u.user_email === userId || u.user_external_id === userId
      );
      
      if (!userRecord) {
        return {
          userId,
          coursesEnrolled: 0,
          coursesCompleted: 0,
          lecturesCompleted: 0,
          minutesLearned: 0,
          lastActive: null,
          source: 'udemy'
        };
      }
      
      // Transform to SkillOS format
      return {
        userId,
        coursesEnrolled: userRecord.num_new_enrolled_courses || 0,
        coursesCompleted: userRecord.num_completed_courses || 0,
        lecturesCompleted: userRecord.num_completed_lectures || 0,
        minutesLearned: userRecord.num_video_consumed_minutes || 0,
        lastActive: userRecord.last_date_visit || null,
        source: 'udemy'
      };
    } catch (error) {
      logger.error(`Error getting user learning activity for SkillOS: ${userId}`, error);
      
      // Return empty result with error info
      return {
        userId,
        coursesEnrolled: 0,
        coursesCompleted: 0,
        lecturesCompleted: 0,
        minutesLearned: 0,
        lastActive: null,
        source: 'udemy',
        error: `Failed to get user activity: ${error.message}`
      };
    }
  }
  
  /**
   * Generate skills gap analysis for SkillOS platform
   * @param {string} userId - User ID in SkillOS
   * @param {string} targetRole - Target role for skills gap analysis
   * @returns {Promise<Object>} - Skills gap analysis in SkillOS format
   */
  async generateSkillsGapAnalysis(userId, targetRole) {
    try {
      logger.info(`Generating skills gap analysis for SkillOS: ${userId}, role: ${targetRole}`);
      
      const developmentPlan = await this.connector.generateCareerDevelopmentPlan(userId, targetRole);
      
      // Transform to SkillOS format
      return {
        userId,
        targetRole,
        currentSkills: developmentPlan.currentSkills.map(skill => ({
          name: skill.name,
          level: skill.proficiency,
          maxLevel: 5
        })),
        requiredSkills: developmentPlan.targetSkills.map(skill => ({
          name: skill.name,
          level: skill.proficiency,
          maxLevel: 5
        })),
        skillGaps: developmentPlan.skillsGap.map(gap => ({
          skill: gap.skill,
          currentLevel: gap.currentProficiency,
          requiredLevel: gap.requiredProficiency,
          gap: gap.gap
        })),
        recommendedCourses: Object.entries(developmentPlan.recommendations).map(([skill, courses]) => ({
          skill,
          courses: courses.map(course => ({
            id: course.id,
            title: course.title,
            imageUrl: course.image,
            url: course.url
          }))
        })),
        source: 'udemy'
      };
    } catch (error) {
      logger.error(`Error generating skills gap analysis for SkillOS: ${userId}`, error);
      throw new Error(`Failed to generate skills gap analysis: ${error.message}`);
    }
  }
  
  /**
   * Launch course for user in SkillOS platform
   * @param {string} courseId - Udemy course ID
   * @param {string} userId - User ID in SkillOS
   * @param {string} returnUrl - URL to return to after course completion
   * @returns {Promise<Object>} - Launch information with URL
   */
  async launchCourse(courseId, userId, returnUrl) {
    try {
      logger.info(`Launching course for SkillOS: ${courseId}, user: ${userId}`);
      
      const ssoUrl = await this.connector.generateCourseSSO(courseId, userId, returnUrl);
      
      return {
        courseId,
        userId,
        launchUrl: ssoUrl,
        success: true
      };
    } catch (error) {
      logger.error(`Error launching course for SkillOS: ${courseId}`, error);
      
      // Return error info
      return {
        courseId,
        userId,
        success: false,
        error: `Failed to launch course: ${error.message}`
      };
    }
  }
}

module.exports = SkillOSUdemyIntegration;
